from django.contrib import admin
from .models import Categoria
from.models import Transacao


admin.site.register(Categoria)
admin.site.register(Transacao)
# Register your models here.
