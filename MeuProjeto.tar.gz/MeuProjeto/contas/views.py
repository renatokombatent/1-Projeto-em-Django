from tarfile import data_filter

from django.shortcuts import render, redirect
from .models import Transacao
from .forms import TransacaoForm

# Create your views here.
from django.http import HttpResponse
import datetime

from pkg_resources import require


def home(request):
    data = {}
    data ['Transações'] = ['t1', 't2', 't3']

    data['now'] = datetime.datetime.now()
    #html = "<html><body>It is now %s.</body></html>" % now
    return render(request, 'contas/home.html', data)

def listagem(request):
    data = {}
    data['transacoes'] = Transacao.objects.all()
    return render(request, 'contas/listagem.html', data)


def nova_transacao(request):
    data = {}
    form = TransacaoForm(request.POST or None)
    if form. is_valid():
        form.save()
        return redirect('url_listagem')


    data ['form'] = form

    return render(request, 'contas/form.html', {'form': data})

def update(request, pk):
    data = {}
    trasnsacao = Transacao.objects.get(pk=pk)
    form = TransacaoForm(request.POST or None, instance=trasnsacao)
    if form.is_valid():
        form.save()
        return redirect('url_listagem')

    data['form'] = form
    data['transacao'] = trasnsacao
    return render(request, 'contas/form.html', {'form': data})

def delete(request, pk):
    transacao = Transacao.object.get(pk=pk)
    transacao.delete()
    return redirect('url_listagem')